detectron2.data.transforms package
====================================

Related tutorial: :doc:`../tutorials/augmentation`.

.. automodule:: detectron2.data.transforms
    :members:
    :undoc-members:
    :show-inheritance:
    :imported-members:
