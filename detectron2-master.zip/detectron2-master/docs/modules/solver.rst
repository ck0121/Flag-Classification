detectron2.solver package
=========================

.. automodule:: detectron2.solver
    :members:
    :undoc-members:
    :show-inheritance:
