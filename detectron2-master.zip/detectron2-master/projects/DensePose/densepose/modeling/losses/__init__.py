# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved

from .densepose_losses import DensePoseLosses
